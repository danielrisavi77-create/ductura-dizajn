# Ductura — upute za rad

- Uvijek kompaktno i nenabacano: progresivno otkrivanje (detalji tek za aktivno poglavlje / pod mišem), bez dekorativnih rubova i "AI slop" ukrasa (npr. lijeva naglasna crta).
- Vizualni stil: prototip Pisač (pisac-editor/public/legacy), tamna tema; list može biti tamni ili bijeli.
- Ime proizvoda u sučelju: Ductura.
- Poštuj PRODUCT.md §5 (rječnik, bez mjera ritma/truda, bez postotaka u studentskom prikazu).
