repo: danielrisavi77-create/Ductus
branch: main

## Last sync
date: 2026-10-17T11:48:53Z
ref: refs/pull/386/head (tokeni D-115)

### Updated in this project
- Analiza frontenda (ekrani, naredbe, pravila, sukobi)
- Pregled prototipa Pisač (danielrisavi77-create/pisac-editor, public/legacy)
- Fontovi Instrument Sans, Newsreader, JetBrains Mono iz app/fonts

## Sync 2026-10-17T15:02:47Z
- Pročitani STATE.md i docs/PLAN-DEMO.md (main); predaja dizajna u design_handoff_ductura/ s opsegom prema PLAN-DEMO §2 i §4

## Sync 2026-10-17T12:34:08Z
- Službene Upute FPZG-a (2013./2015.), fpzg.unizg.hr PDF: opseg (Tablica 2), struktura rada, uvod/zaključak/sažetak, ilustracije, bibliografske jedinice
- FPZG pravila iz danielrisavi77-create/Lekta@master: .claude/katedra-pkg/katedra-lite/references/fakulteti/fpzg.json, fpzg-diplomski/references/struktura.md, stranice-i-izvori.md

## Screen map
| Screen | Repo files |
| --- | --- |
| Ductus analiza | docs/PRODUCT.md, docs/PRODUCT_SPEC_V1.md, docs/PLAN-DEMO.md, docs/FEATURES.md, STATE.md, app/globals.css (PR #386), src/domain/sync/labels.ts, src/lib/i18n/messages.hr.ts |
| Predaja: design_handoff_ductura/ | docs/PLAN-DEMO.md, STATE.md, docs/PRODUCT.md §5 |
| Referenca: index.html + assets/ | pisac-editor: public/legacy/index.html, assets/app.js, assets/styles.css |
